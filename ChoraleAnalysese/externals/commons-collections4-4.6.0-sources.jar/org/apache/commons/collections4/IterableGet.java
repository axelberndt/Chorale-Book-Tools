/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4;

import java.util.Map;
/**
 * The "read" subset of the {@link Map} interface.
 *
 * @param <K> The type of the keys in this map
 * @param <V> The type of the values in this map
 * @since 4.0
 * @see Put
 */
public interface IterableGet<K, V> extends Get<K, V> {

    /**
     * Obtains a {@code MapIterator} over the map.
     * <p>
     * A map iterator is an efficient way of iterating over maps.
     * There is no need to access the entry set or use Map Entry objects.
     * </p>
     * <pre>
     * IterableMap&lt;String,Integer&gt; map = new HashedMap&lt;String,Integer&gt;();
     * MapIterator&lt;String,Integer&gt; it = map.mapIterator();
     * while (it.hasNext()) {
     *   String key = it.next();
     *   Integer value = it.getValue();
     *   it.setValue(value + 1);
     * }
     * </pre>
     *
     * @return A map iterator.
     */
    MapIterator<K, V> mapIterator();

}
