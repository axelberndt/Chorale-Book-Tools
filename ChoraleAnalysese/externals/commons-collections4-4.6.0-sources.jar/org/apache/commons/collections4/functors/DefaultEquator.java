/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4.functors;

import java.io.Serializable;
import java.util.Objects;

import org.apache.commons.collections4.Equator;

/**
 * Default {@link Equator} implementation.
 *
 * @param <T>  the types of object this {@link Equator} can evaluate.
 * @since 4.0
 */
public class DefaultEquator<T> implements Equator<T>, Serializable {

    /** Serial version UID */
    private static final long serialVersionUID = 825802648423525485L;

    /** Static instance */
    @SuppressWarnings("rawtypes") // the static instance works for all types
    public static final DefaultEquator INSTANCE = new DefaultEquator<>();

    /**
     * Hashcode used for {@code null} objects.
     */
    public static final int HASHCODE_NULL = -1;

    /**
     * Factory returning the typed singleton instance.
     *
     * @param <T>  the object type
     * @return The singleton instance
     */
    public static <T> DefaultEquator<T> defaultEquator() {
        return INSTANCE;
    }

    /**
     * Restricted constructor.
     */
    private DefaultEquator() {
    }

    /**
     * {@inheritDoc} Delegates to {@link Objects#equals(Object, Object)}.
     */
    @Override
    public boolean equate(final T o1, final T o2) {
        return Objects.equals(o1, o2);
    }

    /**
     * {@inheritDoc}
     *
     * @return {@code o.hashCode()} if {@code o} is non-
     *         {@code null}, else {@link #HASHCODE_NULL}.
     */
    @Override
    public int hash(final T o) {
        return o == null ? HASHCODE_NULL : o.hashCode();
    }

    /**
     * Returns the singleton instance.
     *
     * @return The singleton instance.
     */
    private Object readResolve() {
        return INSTANCE;
    }

}
