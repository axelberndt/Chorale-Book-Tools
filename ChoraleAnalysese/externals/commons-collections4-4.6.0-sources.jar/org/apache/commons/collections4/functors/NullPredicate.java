/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4.functors;

import java.io.Serializable;

import org.apache.commons.collections4.Predicate;

/**
 * Predicate implementation that returns true if the input is null.
 *
 * @param <T> The type of the input to the predicate.
 * @since 3.0
 */
public final class NullPredicate<T> extends AbstractPredicate<T> implements Serializable {

    /** Serial version UID */
    private static final long serialVersionUID = 7533784454832764388L;

    /** Singleton predicate instance */
    @SuppressWarnings("rawtypes")
    public static final Predicate INSTANCE = new NullPredicate<>();

    /**
     * Factory returning the singleton instance.
     *
     * @param <T> The type that the predicate queries
     * @return The singleton instance
     * @since 3.1
     */
    public static <T> Predicate<T> nullPredicate() {
        return INSTANCE;
    }

    /**
     * Restricted constructor.
     */
    private NullPredicate() {
    }

    /**
     * Returns the singleton instance.
     *
     * @return The singleton instance.
     */
    private Object readResolve() {
        return INSTANCE;
    }

    /**
     * Evaluates the predicate returning true if the input is null.
     *
     * @param object  The input object
     * @return true if input is null
     */
    @Override
    public boolean test(final T object) {
        return object == null;
    }

}
