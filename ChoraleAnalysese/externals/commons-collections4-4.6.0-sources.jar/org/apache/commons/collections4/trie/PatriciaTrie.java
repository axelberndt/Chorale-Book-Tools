/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4.trie;

import java.util.Map;

import org.apache.commons.collections4.Trie;
import org.apache.commons.collections4.trie.analyzer.StringKeyAnalyzer;

/**
 * Implements a PATRICIA Trie (Practical Algorithm to Retrieve Information
 * Coded in Alphanumeric).
 * <p>
 * A PATRICIA {@link Trie} is a compressed
 * {@link Trie}. Instead of storing
 * all data at the edges of the {@link Trie}
 * (and having empty internal nodes), PATRICIA stores data in every node.
 * This allows for very efficient traversal, insert, delete, predecessor,
 * successor, prefix, range, and {@link #select(Object)}
 * operations. All operations are performed at worst in O(K) time, where K
 * is the number of bits in the largest item in the tree. In practice,
 * operations actually take O(A(K)) time, where A(K) is the average number of
 * bits of all items in the tree.
 * </p>
 * <p>
 * Most importantly, PATRICIA requires very few comparisons to keys while
 * doing any operation. While performing a lookup, each comparison (at most
 * K of them, described above) will perform a single bit comparison against
 * the given key, instead of comparing the entire key to another key.
 * </p>
 * <p>
 * The {@link Trie} can return operations in
 * lexicographical order using the 'prefixMap', 'submap', or 'iterator' methods.
 * The {@link Trie} can also
 * scan for items that are 'bitwise' (using an XOR metric) by the 'select' method.
 * Bitwise closeness is determined by the {@link KeyAnalyzer} returning true or
 * false for a bit being set or not in a given key.
 * </p>
 * <p>
 * This PATRICIA {@link Trie} supports both variable
 * length &amp; fixed length keys. Some methods, such as {@link org.apache.commons.collections4.Trie#prefixMap(Object)}
 * are suited only to variable length keys.
 * </p>
 *
 * @param <V> The type of the values in this map
 * @see <a href="https://en.wikipedia.org/wiki/Radix_tree">Radix Tree</a>
 * @see <a href="https://users.monash.edu/~lloyd/tildeAlgDS/Tree/PATRICIA/">PATRICIA</a>
 * @see <a href="https://www.imperialviolet.org/binary/critbit.pdf">Crit-Bit Tree</a>
 * @since 4.0
 */
public class PatriciaTrie<V> extends AbstractPatriciaTrie<String, V> {

    private static final long serialVersionUID = 4446367780901817838L;

    /**
     * Constructs a new instance.
     */
    public PatriciaTrie() {
        super(StringKeyAnalyzer.INSTANCE);
    }

    /**
     * Constructs a new instance.
     *
     * @param map mappings to be stored in this map.
     */
    public PatriciaTrie(final Map<? extends String, ? extends V> map) {
        super(StringKeyAnalyzer.INSTANCE, map);
    }

}
