/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * Implements the
 * {@link org.apache.commons.collections4.Trie Trie} interface.
 * <p>
 * The implementations are in the form of direct implementations and decorators.
 * A decorator wraps another implementation of the interface to add some
 * specific additional functionality.
 * </p>
 * <p>
 * The following implementations are provided in the package:
 * </p>
 * <ul>
 *   <li>PatriciaTrie - an implementation of a PATRICIA trie</li>
 * </ul>
 * <p>
 * The following decorators are provided:
 * </p>
 * <ul>
 *   <li>Unmodifiable - ensures the collection cannot be altered</li>
 * </ul>
 */
package org.apache.commons.collections4.trie;
