/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4.iterators;

import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.apache.commons.collections4.ResettableListIterator;

/**
 * Implements a {@link ListIterator} over an array of objects.
 * <p>
 * This iterator does not support {@link #add} or {@link #remove}, as the object array
 * cannot be structurally modified. The {@link #set} method is supported however.
 * </p>
 * <p>
 * The iterator implements a {@link #reset} method, allowing the reset of the iterator
 * back to the start if required.
 * </p>
 *
 * @param <E> The type of elements returned by this iterator.
 * @see org.apache.commons.collections4.iterators.ObjectArrayIterator
 * @see java.util.Iterator
 * @see java.util.ListIterator
 * @since 3.0
 */
public class ObjectArrayListIterator<E> extends ObjectArrayIterator<E>
        implements ResettableListIterator<E> {

    /**
     * Holds the index of the last item returned by a call to {@code next()}
     * or {@code previous()}. This is set to {@code -1} if neither method
     * has yet been invoked. {@code lastItemIndex} is used to implement the
     * {@link #set} method.
     */
    private int lastItemIndex = -1;

    /**
     * Constructs an ObjectArrayListIterator that will iterate over the values in the
     * specified array.
     *
     * @param array The array to iterate over
     * @throws NullPointerException if {@code array} is {@code null}
     */
    public ObjectArrayListIterator(final E... array) {
        super(array);
    }

    /**
     * Constructs an ObjectArrayListIterator that will iterate over the values in the
     * specified array from a specific start index.
     *
     * @param array  The array to iterate over
     * @param start  The index to start iterating at
     * @throws NullPointerException if {@code array} is {@code null}
     * @throws IndexOutOfBoundsException if the start index is out of bounds
     */
    public ObjectArrayListIterator(final E[] array, final int start) {
        super(array, start);
    }

    /**
     * Constructs an ObjectArrayListIterator that will iterate over a range of values
     * in the specified array.
     *
     * @param array  The array to iterate over
     * @param start  The index to start iterating at
     * @param end  The index (exclusive) to finish iterating at
     * @throws IndexOutOfBoundsException if the start or end index is out of bounds
     * @throws IllegalArgumentException if end index is before the start
     * @throws NullPointerException if {@code array} is {@code null}
     */
    public ObjectArrayListIterator(final E[] array, final int start, final int end) {
        super(array, start, end);
    }

    /**
     * Always throws {@link UnsupportedOperationException}.
     *
     * @param obj Ignored.
     * @throws UnsupportedOperationException Always thrown.
     */
    @Override
    public void add(final E obj) {
        throw new UnsupportedOperationException("add() method is not supported");
    }

    /**
     * Returns true if there are previous elements to return from the array.
     *
     * @return true if there is a previous element to return
     */
    @Override
    public boolean hasPrevious() {
        return index > getStartIndex();
    }

    /**
     * Gets the next element from the array.
     *
     * @return The next element
     * @throws NoSuchElementException if there is no next element
     */
    @Override
    public E next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        lastItemIndex = index;
        return array[index++];
    }

    /**
     * Gets the next index to be retrieved.
     *
     * @return The index of the item to be retrieved next
     */
    @Override
    public int nextIndex() {
        return index - getStartIndex();
    }

    /**
     * Gets the previous element from the array.
     *
     * @return The previous element
     * @throws NoSuchElementException if there is no previous element
     */
    @Override
    public E previous() {
        if (!hasPrevious()) {
            throw new NoSuchElementException();
        }
        lastItemIndex = --index;
        return array[index];
    }

    /**
     * Gets the index of the item to be retrieved if {@link #previous()} is called.
     *
     * @return The index of the item to be retrieved next
     */
    @Override
    public int previousIndex() {
        return index - getStartIndex() - 1;
    }

    /**
     * Resets the iterator back to the start index.
     */
    @Override
    public void reset() {
        super.reset();
        lastItemIndex = -1;
    }

    /**
     * Sets the element under the cursor.
     * <p>
     * This method sets the element that was returned by the last call
     * to {@link #next()} of {@link #previous()}.
     * </p>
     * <p>
     * <strong>Note:</strong> {@link ListIterator} implementations that support {@code add()}
     * and {@code remove()} only allow {@code set()} to be called once per call
     * to {@code next()} or {@code previous} (see the {@link ListIterator}
     * Javadoc for more details). Since this implementation does not support
     * {@code add()} or {@code remove()}, {@code set()} may be
     * called as often as desired.
     * </p>
     *
     * @param obj  The object to set into the array
     * @throws IllegalStateException if next() has not yet been called.
     * @throws ClassCastException if the object type is unsuitable for the array
     */
    @Override
    public void set(final E obj) {
        if (lastItemIndex == -1) {
            throw new IllegalStateException("must call next() or previous() before a call to set()");
        }
        array[lastItemIndex] = obj;
    }

}
