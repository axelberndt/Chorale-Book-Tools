/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.apache.commons.collections4.iterators;

import java.util.ListIterator;
import java.util.Objects;

import org.apache.commons.collections4.Unmodifiable;

/**
 * Decorates a list iterator such that it cannot be modified.
 * <p>
 * Attempts to modify it will result in an UnsupportedOperationException.
 * </p>
 *
 * @param <E> The type of elements returned by this iterator.
 * @since 3.0
 */
public final class UnmodifiableListIterator<E> implements ListIterator<E>, Unmodifiable {

    /**
     * Decorates the specified iterator such that it cannot be modified.
     *
     * @param <E>  the element type
     * @param iterator  The iterator to decorate
     * @return A new unmodifiable list iterator
     * @throws NullPointerException if the iterator is null
     * @deprecated method name has typo in it. Use {@link org.apache.commons.collections4.iterators.UnmodifiableListIterator#unmodifiableListIterator(ListIterator)} instead.
     */
    @Deprecated
    public static <E> ListIterator<E> umodifiableListIterator(final ListIterator<? extends E> iterator) {
        return unmodifiableListIterator(iterator);
    }

    /**
     * Decorates the specified iterator such that it cannot be modified.
     *
     * @param <E>  the element type
     * @param iterator  The iterator to decorate
     * @return A new unmodifiable list iterator
     * @throws NullPointerException if the iterator is null
     */
    public static <E> ListIterator<E> unmodifiableListIterator(final ListIterator<? extends E> iterator) {
        Objects.requireNonNull(iterator, "iterator");
        if (iterator instanceof Unmodifiable) {
            @SuppressWarnings("unchecked") // safe to upcast
            final ListIterator<E> tmpIterator = (ListIterator<E>) iterator;
            return tmpIterator;
        }
        return new UnmodifiableListIterator<>(iterator);
    }

    /** The iterator being decorated */
    private final ListIterator<? extends E> iterator;

    /**
     * Constructs a new instance.
     *
     * @param iterator  The iterator to decorate
     */
    private UnmodifiableListIterator(final ListIterator<? extends E> iterator) {
        this.iterator = iterator;
    }

    /**
     * Always throws {@link UnsupportedOperationException}.
     *
     * @param obj Ignored.
     * @throws UnsupportedOperationException Always thrown.
     */
    @Override
    public void add(final E obj) {
        throw new UnsupportedOperationException("add() is not supported");
    }

    @Override
    public boolean hasNext() {
        return iterator.hasNext();
    }

    @Override
    public boolean hasPrevious() {
        return iterator.hasPrevious();
    }

    @Override
    public E next() {
        return iterator.next();
    }

    @Override
    public int nextIndex() {
        return iterator.nextIndex();
    }

    @Override
    public E previous() {
        return iterator.previous();
    }

    @Override
    public int previousIndex() {
        return iterator.previousIndex();
    }

    /**
     * Always throws {@link UnsupportedOperationException}.
     *
     * @throws UnsupportedOperationException Always thrown.
     */
    @Override
    public void remove() {
        throw new UnsupportedOperationException("remove() is not supported");
    }

    /**
     * Always throws {@link UnsupportedOperationException}.
     *
     * @param ignored Ignored.
     * @throws UnsupportedOperationException Always thrown.
     */
    @Override
    public void set(final E ignored) {
        throw new UnsupportedOperationException("set() is not supported");
    }

}
